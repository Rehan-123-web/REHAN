#include <stdio.h>
int main() {
int i,n;
printf("enter the number of natural number to be printed: ");
scanf("%d",&n);
for(i=1;i<=n;i++){
printf("%d ",i);
}
}
