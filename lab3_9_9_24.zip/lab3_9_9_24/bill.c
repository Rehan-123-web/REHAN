#include <stdio.h>
int main()
{
float p1,p2,p3,p4,p5,totalprice;
printf ("enter the price of all items ;\n" );
scanf("%f%f%f%f%f",&p1,p2,p3,p4,p5);
/*printf ("enter the price of item2 ;\n" );
scanf("%f",&p2);
printf ("enter the price of item3 ;\n" );
scanf("%f",&p3);
printf ("enter the price of item4 ;\n" );
scanf("%f",&p4);
printf ("enter the price of item5 ;\n" );
scanf("%f",&p5);*/
totalprice=p1+p2+p3+p4+p5;
printf ("price of the item1 :%f\n" );
printf ("price of the item2 :%f\n" );
printf ("price of the item3 :%f\n" );
printf ("price of the item4 :%f\n" );
printf ("price of the item5 :%f\n" );
printf ("price of the totalprice :%f\n" );
}
