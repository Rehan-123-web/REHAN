// wite a c-program for print the height for the person. 
#include <stdio.h>
int main() // main is used for starting the program
{
int height;
printf("ENTER YOUR HEIGHT :");
scanf("%d",&height);
printf("my height is : %d\n",height);
}

