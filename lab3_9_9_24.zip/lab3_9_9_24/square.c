#include <stdio.h>
int main()
{
int a,area;
scanf("%d",&a);
printf("length : \n");
scanf("%d",&area);
area= a*a;
printf("area :%d",area);
}
