#include <stdio.h>
int main()
{
float p,r,t,S;
printf("enter the value of p :");
scanf("%d",&p);
printf("enter the value of r :");
scanf("%d",&r);
printf("enter the value of t :");
scanf("%d",&t);
scanf("%d",&S);
S=p*r*t/100;
printf("the value of simple interest :%d\n",S);
}
