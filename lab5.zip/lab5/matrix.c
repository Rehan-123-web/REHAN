#include <stdio.h>
int main(){
int i=3,j=2;
for (i=1;i<3;i++)
{
   for(j=1;j<4;j++){
   printf("(%d,%d)\t",i,j);
   }
   printf("\n");
}
}

