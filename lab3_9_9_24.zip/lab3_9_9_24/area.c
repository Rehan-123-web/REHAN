#include <stdio.h>
int main()
{
int l,b,area;
printf("length of rectangle :\n");
printf("breadth of rectangle :\n");
scanf("%d%d",&l,&b);
scanf("%d",&area);
area =l*b;
printf("area: %d",area);
}
