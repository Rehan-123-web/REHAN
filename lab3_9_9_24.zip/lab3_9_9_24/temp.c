#include <stdio.h>
int main() 
{ 
float f,c ;
scanf("%f",&f);
printf("ENTER TEMPERATURE IN FEHRENHEIT DEGREES: ");
 c=5/9*(f-32);
 printf("temp in centigrade degrees=%f\n",c);
}
